-- Refresh database types
-- All tables are already created, this migration just triggers type regeneration
SELECT 1;